رایا v1.0.0

مسیر API پیش‌فرض داخل اپ:
https://gaminoapp.ir/raya/api

برای راه‌اندازی:
1) محتوای ZIP بک‌اند را در public_html/raya/api آپلود کنید.
2) آدرس https://gaminoapp.ir/raya/api/setup.php را باز کنید و دیتابیس/ادمین را بسازید.
3) محتوای ZIP پنل را در public_html/raya/admin-panel آپلود کنید.
4) سورس Flutter را در GitHub قرار دهید و Workflow را اجرا کنید.

امضای APK:
- فایل JKS و key.properties داخل android_signing قرار دارد.
- برای ساخت release نیازی به افزودن GitHub Secrets نیست.
- Workflow خودش کی‌استور را آماده و APK/AAB امضاشده خروجی می‌گیرد.

Package Name:
com.manyplus.raya


تغییرات v1.0.1+2:
- اضافه شدن مجوز اینترنت و وضعیت شبکه به AndroidManifest هنگام ساخت با GitHub Actions.
- رفع خطای اتصال به سرور در ثبت‌نام/ورود نسخه Release.
