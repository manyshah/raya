رایا v1.0.2+3 - Connection/Auth Fix
- POST فرم برای سازگاری با cPanel/PHP
- نمایش خطای دقیق اتصال
- حفظ مسیر API: https://gaminoapp.ir/raya/api
