import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

const List<String> kApiBaseUrls = [
  'https://gaminoapp.ir/raya/api',
  'https://www.gaminoapp.ir/raya/api',
];
const String kApiBaseUrl = kApiBaseUrls.first;
const String kAppName = 'رایا';
const String kPackageName = 'com.manyplus.raya';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Color(0xFF07111F),
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const RayaApp());
}

class RayaApp extends StatelessWidget {
  const RayaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      locale: const Locale('fa'),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4F8CFF),
          brightness: Brightness.dark,
          primary: const Color(0xFF65A7FF),
          secondary: const Color(0xFF50F2C4),
          surface: const Color(0xFF0D1828),
        ),
        scaffoldBackgroundColor: const Color(0xFF07111F),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF132238),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
      home: const BootstrapPage(),
    );
  }
}

class ApiClient {
  String? token;
  final http.Client _client = http.Client();

  Future<void> loadToken() async {
    final sp = await SharedPreferences.getInstance();
    token = sp.getString('token');
  }

  Future<void> saveToken(String value) async {
    token = value;
    final sp = await SharedPreferences.getInstance();
    await sp.setString('token', value);
  }

  Future<void> clearToken() async {
    token = null;
    final sp = await SharedPreferences.getInstance();
    await sp.remove('token');
  }

  Map<String, String> get _headers => {
        'Content-Type': 'application/json; charset=utf-8',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Future<Map<String, dynamic>> post(String route, Map<String, dynamic> body) async {
    Object? lastError;

    for (final base in kApiBaseUrls) {
      final uri = Uri.parse('$base/index.php?route=$route');
      try {
        final res = await _client.post(
          uri,
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'RayaAndroid/1.0.3',
            if (token != null) 'Authorization': 'Bearer $token',
          },
          body: body.map((key, value) => MapEntry(key, value?.toString() ?? '')),
        ).timeout(const Duration(seconds: 45));

        final text = utf8.decode(res.bodyBytes).trim();
        if (text.isEmpty) {
          return {'success': false, 'message': 'پاسخ سرور خالی است. کد وضعیت: ${res.statusCode}'};
        }

        final data = jsonDecode(text);
        if (data is Map<String, dynamic>) return data;
        return {'success': false, 'message': 'پاسخ سرور نامعتبر است'};
      } on TimeoutException catch (e) {
        lastError = e;
      } on FormatException catch (e) {
        return {'success': false, 'message': 'پاسخ سرور JSON نیست: ${e.message}'};
      } catch (e) {
        lastError = e;
      }
    }

    final errorText = lastError.toString();
    if (errorText.contains('Failed host lookup') || errorText.contains('No address associated')) {
      return {'success': false, 'message': 'خطای DNS گوشی: دامنه gaminoapp.ir روی اینترنت فعلی گوشی پیدا نشد. یکبار VPN/Private DNS را خاموش یا روشن کن، یا با Wi‑Fi تست کن. جزئیات: $errorText'};
    }
    return {'success': false, 'message': 'خطای اتصال: $errorText'};
  }

  Future<Map<String, dynamic>> get(String route) async {
    Object? lastError;
    for (final base in kApiBaseUrls) {
      final uri = Uri.parse('$base/index.php?route=$route');
      try {
        final res = await _client.get(uri, headers: _headers).timeout(const Duration(seconds: 25));
        final data = jsonDecode(utf8.decode(res.bodyBytes));
        if (data is Map<String, dynamic>) return data;
        return {'success': false, 'message': 'پاسخ سرور نامعتبر است'};
      } catch (e) {
        lastError = e;
      }
    }
    final errorText = lastError.toString();
    if (errorText.contains('Failed host lookup') || errorText.contains('No address associated')) {
      return {'success': false, 'message': 'خطای DNS گوشی: دامنه gaminoapp.ir روی اینترنت فعلی گوشی پیدا نشد. VPN/Private DNS یا شبکه را تغییر بده. جزئیات: $errorText'};
    }
    return {'success': false, 'message': 'خطای اتصال: $errorText'};
  }
}

final api = ApiClient();

class BootstrapPage extends StatefulWidget {
  const BootstrapPage({super.key});
  @override
  State<BootstrapPage> createState() => _BootstrapPageState();
}

class _BootstrapPageState extends State<BootstrapPage> {
  bool loading = true;
  bool authed = false;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await api.loadToken();
    if (api.token != null) {
      final me = await api.get('me');
      authed = me['success'] == true;
      if (!authed) await api.clearToken();
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const SplashPage();
    return authed ? const ShellPage() : const AuthPage();
  }
}

class SplashPage extends StatelessWidget {
  const SplashPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF14345F), Color(0xFF07111F), Color(0xFF101827)]),
        ),
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                gradient: const LinearGradient(colors: [Color(0xFF65A7FF), Color(0xFF50F2C4)]),
                boxShadow: [BoxShadow(color: const Color(0xFF65A7FF).withOpacity(.35), blurRadius: 30)],
              ),
              child: const Center(child: Text('ر', style: TextStyle(fontSize: 52, fontWeight: FontWeight.w900, color: Colors.white))),
            ),
            const SizedBox(height: 20),
            const Text('رایا', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('دستیار هوش مصنوعی شما', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 26),
            const SizedBox(width: 130, child: LinearProgressIndicator(minHeight: 5, borderRadius: BorderRadius.all(Radius.circular(8)))),
          ]),
        ),
      ),
    );
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool login = true;
  bool busy = false;
  final name = TextEditingController();
  final email = TextEditingController();
  final pass = TextEditingController();

  Future<void> submit() async {
    setState(() => busy = true);
    try {
      final data = await api.post(login ? 'auth/login' : 'auth/register', {
        'name': name.text.trim(),
        'email': email.text.trim(),
        'password': pass.text,
      });
      if (data['success'] == true && data['token'] != null) {
        await api.saveToken(data['token']);
        if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const ShellPage()));
      } else {
        _toast(data['message']?.toString() ?? 'خطا در ورود');
      }
    } catch (e) {
      _toast('خطای اتصال: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  void _toast(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF102A4A), Color(0xFF07111F)])),
          child: ListView(padding: const EdgeInsets.all(22), children: [
            const SizedBox(height: 30),
            const Text('رایا', textAlign: TextAlign.center, style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('چت، کدنویسی، ساخت عکس و دستیار صوتی', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 36),
            GlassCard(child: Column(children: [
              Text(login ? 'ورود به حساب' : 'ثبت‌نام در رایا', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 18),
              if (!login) TextField(controller: name, decoration: const InputDecoration(labelText: 'نام')), 
              if (!login) const SizedBox(height: 12),
              TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'ایمیل')),
              const SizedBox(height: 12),
              TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'رمز عبور')),
              const SizedBox(height: 18),
              SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: busy ? null : submit, child: busy ? const CircularProgressIndicator() : Text(login ? 'ورود' : 'ساخت حساب'))),
              TextButton(onPressed: busy ? null : () => setState(() => login = !login), child: Text(login ? 'حساب نداری؟ ثبت‌نام کن' : 'حساب داری؟ وارد شو')),
            ])),
          ]),
        ),
      ),
    );
  }
}

class ShellPage extends StatefulWidget {
  const ShellPage({super.key});
  @override
  State<ShellPage> createState() => _ShellPageState();
}

class _ShellPageState extends State<ShellPage> {
  int index = 0;
  Map<String, dynamic>? me;

  @override
  void initState() {
    super.initState();
    refreshMe();
  }

  Future<void> refreshMe() async {
    final data = await api.get('me');
    if (mounted && data['success'] == true) setState(() => me = data['user']);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [ChatPage(onUsageChanged: refreshMe), ImagePage(onUsageChanged: refreshMe), const PlansPage(), ProfilePage(me: me, onLogout: () async {
      await api.clearToken();
      if (mounted) Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const AuthPage()), (_) => false);
    })];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Row(children: [
          const RayaLogo(size: 36),
          const SizedBox(width: 10),
          const Text('رایا', style: TextStyle(fontWeight: FontWeight.w900)),
          const Spacer(),
          if (me != null) CreditPill(credits: me!['credits'] ?? 0, plan: me!['plan'] ?? 'free'),
        ]),
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'چت'),
          NavigationDestination(icon: Icon(Icons.image_outlined), selectedIcon: Icon(Icons.image), label: 'عکس'),
          NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), selectedIcon: Icon(Icons.workspace_premium), label: 'پلن‌ها'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'پروفایل'),
        ],
      ),
    );
  }
}

class ChatMessage {
  ChatMessage(this.role, this.text);
  final String role;
  final String text;
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key, required this.onUsageChanged});
  final VoidCallback onUsageChanged;
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController();
  final scroll = ScrollController();
  bool busy = false;
  final messages = <ChatMessage>[
    ChatMessage('assistant', 'سلام، من رایا هستم. سؤال بپرس، کد بخواه، متن بساز یا ایده بگیر.'),
  ];

  Future<void> send() async {
    final text = input.text.trim();
    if (text.isEmpty || busy) return;
    input.clear();
    setState(() {
      messages.add(ChatMessage('user', text));
      busy = true;
    });
    _scrollBottom();
    try {
      final data = await api.post('chat/send', {'message': text});
      final reply = data['success'] == true ? (data['reply'] ?? 'پاسخی دریافت نشد').toString() : (data['message'] ?? 'خطا در دریافت پاسخ').toString();
      setState(() => messages.add(ChatMessage('assistant', reply)));
      widget.onUsageChanged();
    } catch (_) {
      setState(() => messages.add(ChatMessage('assistant', 'اتصال به سرور انجام نشد.')));
    }
    setState(() => busy = false);
    _scrollBottom();
  }

  void _scrollBottom() => Future.delayed(const Duration(milliseconds: 100), () {
    if (scroll.hasClients) scroll.animateTo(scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
  });

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      SizedBox(
        height: 86,
        child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
          PromptChip('یک کد لاگین Flutter بساز', input),
          PromptChip('این متن را رسمی‌تر کن', input),
          PromptChip('برای پیج اینستاگرام ایده بده', input),
          PromptChip('یک برنامه روزانه بنویس', input),
        ]),
      ),
      Expanded(
        child: ListView.builder(
          controller: scroll,
          padding: const EdgeInsets.all(14),
          itemCount: messages.length + (busy ? 1 : 0),
          itemBuilder: (context, i) {
            if (i >= messages.length) return const AssistantTyping();
            final m = messages[i];
            final isUser = m.role == 'user';
            return Align(
              alignment: isUser ? Alignment.centerLeft : Alignment.centerRight,
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 7),
                constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .84),
                decoration: BoxDecoration(
                  color: isUser ? const Color(0xFF276EF1) : const Color(0xFF132238),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(.06)),
                ),
                padding: const EdgeInsets.all(14),
                child: isUser ? Text(m.text, style: const TextStyle(height: 1.65)) : SelectableText(m.text, style: const TextStyle(height: 1.65)),
              ),
            );
          },
        ),
      ),
      SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
          child: Row(children: [
            IconButton.filledTonal(onPressed: () => _voiceInfo(), icon: const Icon(Icons.mic)),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: input, minLines: 1, maxLines: 5, decoration: const InputDecoration(hintText: 'از رایا بپرس...'), onSubmitted: (_) => send())),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: busy ? null : send, icon: const Icon(Icons.send)),
          ]),
        ),
      ),
    ]);
  }

  void _voiceInfo() {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('دستیار صوتی رایا'),
      content: const Text('در نسخه اول دکمه صوتی آماده‌سازی شده است. در نسخه بعد می‌توانیم تشخیص گفتار و پاسخ صوتی را فعال کنیم.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('باشه'))],
    ));
  }
}

class ImagePage extends StatefulWidget {
  const ImagePage({super.key, required this.onUsageChanged});
  final VoidCallback onUsageChanged;
  @override
  State<ImagePage> createState() => _ImagePageState();
}

class _ImagePageState extends State<ImagePage> {
  final prompt = TextEditingController();
  bool busy = false;
  String? imageUrl;
  XFile? picked;

  Future<void> generate() async {
    final text = prompt.text.trim();
    if (text.isEmpty || busy) return;
    setState(() { busy = true; imageUrl = null; });
    try {
      final data = await api.post('image/generate', {'prompt': text});
      if (data['success'] == true) {
        setState(() => imageUrl = data['image_url']?.toString());
        widget.onUsageChanged();
      } else {
        _toast(data['message']?.toString() ?? 'ساخت عکس انجام نشد');
      }
    } catch (e) {
      _toast('خطای اتصال: $e');
    }
    setState(() => busy = false);
  }

  Future<void> pickImage() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (x != null) setState(() => picked = x);
  }

  void _toast(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('ساخت عکس با رایا', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('در پلن رایگان روزانه ۴ عکس قابل ساخت است.', style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 16),
        TextField(controller: prompt, minLines: 3, maxLines: 6, decoration: const InputDecoration(hintText: 'مثلاً: یک لوگوی مینیمال برای اپ هوش مصنوعی رایا...')),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: busy ? null : generate, icon: const Icon(Icons.auto_awesome), label: Text(busy ? 'در حال ساخت...' : 'ساخت عکس'))),
          const SizedBox(width: 10),
          IconButton.filledTonal(onPressed: pickImage, icon: const Icon(Icons.edit)),
        ]),
        if (picked != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text('عکس برای ویرایش انتخاب شد: ${picked!.name}', style: const TextStyle(color: Colors.white70))),
      ])),
      const SizedBox(height: 16),
      if (busy) const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator())),
      if (imageUrl != null) ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.network(imageUrl!, fit: BoxFit.cover)),
      const SizedBox(height: 16),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text('ویرایش عکس', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        SizedBox(height: 8),
        Text('زیرساخت انتخاب عکس آماده است. اتصال ویرایش واقعی عکس در نسخه بعد به بک‌اند اضافه می‌شود.', style: TextStyle(color: Colors.white70, height: 1.6)),
      ])),
    ]);
  }
}

class PlansPage extends StatelessWidget {
  const PlansPage({super.key});
  @override
  Widget build(BuildContext context) {
    final plans = [
      ('رایگان', '۴ عکس روزانه، چت محدود، مناسب تست', Icons.lock_open),
      ('معمولی', 'چت بیشتر، عکس بیشتر، سرعت بهتر', Icons.bolt),
      ('پلاس', 'مدل بهتر، محدودیت بالاتر، تاریخچه بیشتر', Icons.workspace_premium),
      ('پرو', 'اولویت بالا، ابزارهای پیشرفته، مصرف حرفه‌ای', Icons.diamond),
    ];
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('پلن‌های رایا', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
      const SizedBox(height: 14),
      for (final p in plans) Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: GlassCard(child: Row(children: [
          Container(width: 52, height: 52, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [Color(0xFF65A7FF), Color(0xFF50F2C4)])), child: Icon(p.$3, color: Colors.white)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(p.$1, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(p.$2, style: const TextStyle(color: Colors.white70, height: 1.5))])),
          const Icon(Icons.chevron_left),
        ])),
      ),
    ]);
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key, required this.me, required this.onLogout});
  final Map<String, dynamic>? me;
  final VoidCallback onLogout;
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      GlassCard(child: Column(children: [
        const RayaLogo(size: 82),
        const SizedBox(height: 14),
        Text(me?['name']?.toString() ?? 'کاربر رایا', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        Text(me?['email']?.toString() ?? '', style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 18),
        Row(children: [
          Expanded(child: StatBox(label: 'اعتبار', value: '${me?['credits'] ?? 0}')),
          const SizedBox(width: 10),
          Expanded(child: StatBox(label: 'پلن', value: '${me?['plan'] ?? 'free'}')),
        ]),
        const SizedBox(height: 18),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: onLogout, icon: const Icon(Icons.logout), label: const Text('خروج از حساب'))),
      ])),
      const SizedBox(height: 14),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text('قوانین استفاده', style: TextStyle(fontWeight: FontWeight.w900)),
        SizedBox(height: 8),
        Text('پاسخ‌های هوش مصنوعی ممکن است خطا داشته باشند. قبل از استفاده جدی، نتیجه را بررسی کنید.', style: TextStyle(color: Colors.white70, height: 1.6)),
      ])),
    ]);
  }
}

class GlassCard extends StatelessWidget {
  const GlassCard({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        color: const Color(0xFF101D30).withOpacity(.88),
        border: Border.all(color: Colors.white.withOpacity(.08)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 22, offset: const Offset(0, 12))],
      ),
      child: child,
    );
  }
}

class RayaLogo extends StatelessWidget {
  const RayaLogo({super.key, this.size = 44});
  final double size;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(size * .3), gradient: const LinearGradient(colors: [Color(0xFF65A7FF), Color(0xFF50F2C4)])),
      child: Center(child: Text('ر', style: TextStyle(fontSize: size * .52, fontWeight: FontWeight.w900, color: Colors.white))),
    );
  }
}

class CreditPill extends StatelessWidget {
  const CreditPill({super.key, required this.credits, required this.plan});
  final dynamic credits;
  final dynamic plan;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(color: const Color(0xFF132238), borderRadius: BorderRadius.circular(999), border: Border.all(color: Colors.white.withOpacity(.08))),
      child: Row(children: [const Icon(Icons.toll, size: 16, color: Color(0xFF50F2C4)), const SizedBox(width: 5), Text('$credits'), const SizedBox(width: 6), Text('$plan', style: const TextStyle(color: Colors.white54, fontSize: 12))]),
    );
  }
}

class PromptChip extends StatelessWidget {
  const PromptChip(this.text, this.controller, {super.key});
  final String text;
  final TextEditingController controller;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8, top: 18, bottom: 18),
      child: ActionChip(label: Text(text), onPressed: () => controller.text = text),
    );
  }
}

class AssistantTyping extends StatelessWidget {
  const AssistantTyping({super.key});
  @override
  Widget build(BuildContext context) {
    return Align(alignment: Alignment.centerRight, child: Container(margin: const EdgeInsets.symmetric(vertical: 7), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF132238), borderRadius: BorderRadius.circular(20)), child: const Row(mainAxisSize: MainAxisSize.min, children: [SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)), SizedBox(width: 10), Text('رایا در حال پاسخ است...')])));
  }
}

class StatBox extends StatelessWidget {
  const StatBox({super.key, required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) {
    return Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: const Color(0xFF07111F)), child: Column(children: [Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(label, style: const TextStyle(color: Colors.white60))]));
  }
}
