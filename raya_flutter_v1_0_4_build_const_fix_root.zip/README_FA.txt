رایا v1.0.4+5

رفع خطای DNS/Failed host lookup با fallback به www و پیام خطای دقیق‌تر.
بک‌اند ثابت: https://gaminoapp.ir/raya/api
پکیج: com.manyplus.raya
