رایا v1.0.4+5

رفع خطای DNS/Failed host lookup با fallback به www و پیام خطای دقیق‌تر.
بک‌اند ثابت: https://gaminoapp.ir/raya/api
پکیج: com.manyplus.raya


نسخه 1.0.5: حذف fallback آدرس www و اتصال فقط به https://gaminoapp.ir/raya/api برای رفع خطای DNS.
