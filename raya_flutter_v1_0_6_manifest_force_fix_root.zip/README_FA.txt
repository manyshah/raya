رایا v1.0.6+7

اصلاح مهم:
- Workflow به‌صورت اجباری INTERNET permission و ACCESS_NETWORK_STATE را داخل AndroidManifest.xml تزریق می‌کند.
- بعد از تزریق، Manifest در لاگ چاپ می‌شود تا قابل بررسی باشد.
- خروجی APK/AAB با نسخه 1.0.6+7 ساخته می‌شود.

API:
https://gaminoapp.ir/raya/api

Package:
com.manyplus.raya
